library(readxl)
library(tibble)
library(dplyr)
library(plotly)
library(tidyverse)
library(ggplot2)
my_data=read_excel("/Users/gideontesfai/Downloads/data(3).xls")

############  Current DOllar 
my_data=my_data[10:190,]

# Colomn names 
colnames(my_data) <- c("Year","T_elementary", "e1","S_highschool","e2","nocompletion","e3","C_highschool","e4","S_college_no_degree","e5","Associates_degree","e6",
                       "T_degree","e7","Bachelor_degree","e8","Master_degree","e9","Professional_degree","e10","Doctor_degree","e11"	)





my_data=add_column(my_data,Gender=1:181,.after="Year")
my_data$Gender[c(1:21,47:68,94:115,141:160)] <- "Male"
my_data$Gender[c(23:45,70:92,117:139,162:181)] <- "Female"

my_data=add_column(my_data,Type_measure=1:181,.after="Gender")
my_data$Type_measure[1:44] <- "Current"
my_data$Type_measure[46:92] <- "Constant"
my_data$Type_measure[93:138] <- "Number"
my_data$Type_measure[140:181] <- "Percent"

my_data=my_data[c(-22,-45,-46,-69,-92,-93,-116,-139,-140,-161),]



my_data =my_data %>% 
  filter(Year >1995)

my_data=my_data%>% 
  mutate_at(vars(names(my_data)[c(-2,-3)] ), as.integer)%>%
  mutate_at(vars(names(my_data)[4] ), as.integer)



 

ui <-navbarPage(navbarPage(strong("Data Vidualization"), collapsible = TRUE, inverse = TRUE, theme = shinytheme("spacelab")),
                h4(strong("Median Annual Earnings, Number, 
                and Percentage of FullTime Year-Round Workers Age 25 and Over, 
                By Highest Level of Educational Attainment and Sex:2000 through 2019", align = "center")),
  sidebarPanel(
    radioButtons("state_show",
                            label = h3(strong("Type Of Measure")),
                            choices = c( "Current Dollars" = "Current",
                                         "Constant 2019 Dollar" = "Constant",
                                         'Number of Persons with Fulltime Job Annula Earning' = 'Number' ,
                                         "Percent of Persons with Fulltime JOb Annual Earning" = "Percent"
                                         )
                )
                
         
  ),
  sidebarLayout(
                sidebarPanel(selectInput("education1_show",
                            label = h3(strong("Education Level 1")),
                            choices = c( "Total Elementary/Secondary less than 9th grade" = "T_elementary",
                                         "Some High School"  = "S_highschool",
                                         "No High School Completion"  = "nocompletion"  ,
                                         "High schoolcompletion(includes equivalency to HS)" = "C_highschool",
                                         "Some College No Degree"  = "S_college_no_degree",
                                         "Associates degree" = "Associates_degree",
                                         "Total with Degree" = "T_degree",
                                         "Bachelor degree"="Bachelor_degree",
                                         "Master's degree"  = "Master_degree",
                                         "Professional degree"="Professional_degree",
                                         "Doctor's degree" ="Doctor_degree" 
                                         
                                         
                            )
                ),
              
                
                


    selectInput("education2_show",
                             label = h3(strong("Education Level 2")),
                             choices = c( "Total Elementary/Secondary less than 9th grade" = "T_elementary",
                                          "Some High School"  = "S_highschool",
                                          "No High School Completion"  = "nocompletion"  ,
                                          "High schoolcompletion(includes equivalency to HS)" = "C_highschool",
                                          "Some College No Degree"  = "S_college_no_degree",
                                          "Associates degree" = "Associates_degree",
                                          "Total with Degree" = "T_degree",
                                          "Bachelor degree"="Bachelor_degree",
                                          "Master's degree"  = "Master_degree",
                                          "Professional degree"="Professional_degree",
                                          "Doctor's degree" ="Doctor_degree" ),selected ="T_degree" )),
  mainPanel( 
    tabsetPanel(type = "tabs",
      tabPanel(h3(strong("Education Levels Plot",align="center")),
               fluidRow(
                 column(width = 6.0, plotlyOutput("education1")),
                 column(width = 6.0, plotlyOutput("education2")))),
      tabPanel(h3(strong("Difference Between Education Plot",align="center")),
               column(10, plotlyOutput("difference"))))
      )
    )
   
  
  )

get_data=function(education,measure){
  data_sample = my_data %>% select("Year",education,"Gender","Type_measure")%>%
    mutate(my_data[,which(colnames(my_data) == education) +1])
  names(data_sample)[5] = gsub(pattern = "e.*", replacement = "error", x = names(data_sample))
  data_sample=data_sample %>% filter(Type_measure==measure)
  return(data_sample)
}

gg_function=function(education,measure){
  
  pd <- position_dodge(0.3)
  data_try=get_data(education,measure)
  ##### ggplot using index 
  
  p <- plot_ly(data=data_try, x = ~Year, y = data_try[,education][[1]],
               error_y = list(array=~Yerror),
               color=~Gender, type = 'scatter', mode = 'line')%>%
    layout(title ="Education Level" , plot_bgcolor = "#e5ecf6", 
           yaxis = list(title = paste("Measurement Type:", measure)), 
           xaxis = list(title = 'Year'), 
           legend = list(title=list(text='<b> Gender </b>')))
    
  return(p )
}

data_difference=function(education1,education2,measure){
  data_sample = my_data %>% select("Year",education1,education2,"Gender","Type_measure")%>%
    filter(Type_measure==measure)
  data_sample=data_sample%>%mutate(calculation = .data[[education1]] - .data[[education2]])
  p <- plot_ly(data=data_sample, x = ~Year, y = ~calculation,
               color=~Gender, type = 'scatter', mode = 'line')%>%
    layout(title ="Difference between Educational Level 1 and 2" , plot_bgcolor = "#e5ecf6", 
           yaxis = list(title = paste("Deference In Education Level:", measure)), 
           xaxis = list(title = 'Year'), 
           legend = list(title=list(text='<b> Gender </b>')))
  return(p)
  
}

server <- (function(input, output){
  
  output$education1 <- renderPlotly({
    gg_function(input$education1_show,input$state_show)
  })
  
  output$education2 <- renderPlotly({
    gg_function(input$education2_show,input$state_show)
  })


output$difference<-renderPlotly({
  data_difference(input$education1_show,input$education2_show,input$state_show)
})

})


shinyApp(ui = ui, server = server)

